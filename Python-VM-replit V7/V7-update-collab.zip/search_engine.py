import requests


query_inp = input("Enter your query: ")

def wikipedia_search(query):
    """
    Searches Wikipedia using its API.

    Args:
        query: The search term.

    Returns:
        A list of search results (dictionaries).
    """

    url = f'https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch={query}&format=json'
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        return data['query']['search']
    else:
        print(f"Error: {response.status_code}")
        return []

# Example usage
results = wikipedia_search(query_inp)

for result in results:
    print(f"Title: {result['title']}")
    print(f"Snippet: {result['snippet']}")
    print(f"URL: https://en.wikipedia.org/wiki/{result['title'].replace(' ', '_')}\n")